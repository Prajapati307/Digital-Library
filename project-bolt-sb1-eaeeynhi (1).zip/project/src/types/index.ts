export interface User {
  id: string;
  username: string;
  email: string;
  profilePicture?: string;
  createdAt: Date;
  isAdmin?: boolean;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  cover?: string;
  file: string; // Base64 encoded file
  fileType: 'pdf' | 'epub' | 'other';
  genre?: string;
  language?: string;
  description?: string;
  isPublic: boolean;
  addedAt: Date;
  lastRead?: Date;
  currentPage?: number;
  totalPages?: number;
  userId: string;
  tags: string[];
}

export interface BookFilter {
  searchTerm?: string;
  genre?: string;
  language?: string;
  isPublic?: boolean;
  tags?: string[];
}

export interface ReadingSettings {
  fontSize: number;
  lineHeight: number;
  theme: 'light' | 'sepia' | 'dark';
  fontFamily: string;
}

export interface Bookmark {
  id: string;
  bookId: string;
  userId: string;
  page: number;
  note?: string;
  createdAt: Date;
}

export type AuthStatus = 'authenticated' | 'unauthenticated' | 'loading';