import { createContext, useState, useEffect, ReactNode } from 'react';
import { Book, BookFilter, Bookmark, ReadingSettings } from '../types';
import { useAuth } from '../hooks/useAuth';

interface LibraryContextType {
  books: Book[];
  bookmarks: Bookmark[];
  readingSettings: ReadingSettings;
  loading: boolean;
  addBook: (book: Omit<Book, 'id' | 'userId' | 'addedAt'>) => Promise<string>;
  updateBook: (id: string, bookData: Partial<Book>) => Promise<boolean>;
  deleteBook: (id: string) => Promise<boolean>;
  getBook: (id: string) => Book | undefined;
  filterBooks: (filter: BookFilter) => Book[];
  addBookmark: (bookmark: Omit<Bookmark, 'id' | 'userId' | 'createdAt'>) => Promise<string>;
  removeBookmark: (id: string) => Promise<boolean>;
  getBookmarks: (bookId: string) => Bookmark[];
  updateReadingSettings: (settings: Partial<ReadingSettings>) => void;
  updateReadingProgress: (bookId: string, page: number) => Promise<boolean>;
}

const defaultReadingSettings: ReadingSettings = {
  fontSize: 18,
  lineHeight: 1.5,
  theme: 'light',
  fontFamily: 'Literata',
};

export const LibraryContext = createContext<LibraryContextType>({
  books: [],
  bookmarks: [],
  readingSettings: defaultReadingSettings,
  loading: true,
  addBook: async () => '',
  updateBook: async () => false,
  deleteBook: async () => false,
  getBook: () => undefined,
  filterBooks: () => [],
  addBookmark: async () => '',
  removeBookmark: async () => false,
  getBookmarks: () => [],
  updateReadingSettings: () => {},
  updateReadingProgress: async () => false,
});

export const LibraryProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const [books, setBooks] = useState<Book[]>([]);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [readingSettings, setReadingSettings] = useState<ReadingSettings>(
    () => {
      const storedSettings = localStorage.getItem('readingSettings');
      return storedSettings 
        ? JSON.parse(storedSettings) 
        : defaultReadingSettings;
    }
  );
  const [loading, setLoading] = useState(true);

  // Load user's books and bookmarks on login
  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      setBooks([]);
      setBookmarks([]);
    }
  }, [user]);

  // Save reading settings when they change
  useEffect(() => {
    localStorage.setItem('readingSettings', JSON.stringify(readingSettings));
  }, [readingSettings]);

  const loadUserData = () => {
    setLoading(true);
    try {
      // Load books
      const allBooks = JSON.parse(localStorage.getItem('books') || '[]');
      const userBooks = user ? allBooks.filter((book: Book) => book.userId === user.id) : [];
      setBooks(userBooks);

      // Load bookmarks
      const allBookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
      const userBookmarks = user ? allBookmarks.filter((bookmark: Bookmark) => bookmark.userId === user.id) : [];
      setBookmarks(userBookmarks);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const addBook = async (
    bookData: Omit<Book, 'id' | 'userId' | 'addedAt'>
  ): Promise<string> => {
    if (!user) return '';
    
    const newBook: Book = {
      ...bookData,
      id: crypto.randomUUID(),
      userId: user.id,
      addedAt: new Date(),
      tags: bookData.tags || [],
    };

    const allBooks = JSON.parse(localStorage.getItem('books') || '[]');
    allBooks.push(newBook);
    localStorage.setItem('books', JSON.stringify(allBooks));
    
    setBooks(prevBooks => [...prevBooks, newBook]);
    return newBook.id;
  };

  const updateBook = async (
    id: string, 
    bookData: Partial<Book>
  ): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const allBooks = JSON.parse(localStorage.getItem('books') || '[]');
      const updatedBooks = allBooks.map((book: Book) => 
        book.id === id && book.userId === user.id
          ? { ...book, ...bookData }
          : book
      );
      
      localStorage.setItem('books', JSON.stringify(updatedBooks));
      
      setBooks(prevBooks => 
        prevBooks.map(book => 
          book.id === id ? { ...book, ...bookData } : book
        )
      );
      
      return true;
    } catch (error) {
      console.error('Error updating book:', error);
      return false;
    }
  };

  const deleteBook = async (id: string): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const allBooks = JSON.parse(localStorage.getItem('books') || '[]');
      const updatedBooks = allBooks.filter(
        (book: Book) => !(book.id === id && book.userId === user.id)
      );
      
      localStorage.setItem('books', JSON.stringify(updatedBooks));
      
      setBooks(prevBooks => prevBooks.filter(book => book.id !== id));
      
      // Also remove all bookmarks for this book
      const allBookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
      const updatedBookmarks = allBookmarks.filter(
        (bookmark: Bookmark) => bookmark.bookId !== id
      );
      
      localStorage.setItem('bookmarks', JSON.stringify(updatedBookmarks));
      setBookmarks(prevBookmarks => 
        prevBookmarks.filter(bookmark => bookmark.bookId !== id)
      );
      
      return true;
    } catch (error) {
      console.error('Error deleting book:', error);
      return false;
    }
  };

  const getBook = (id: string): Book | undefined => {
    return books.find(book => book.id === id);
  };

  const filterBooks = (filter: BookFilter): Book[] => {
    return books.filter(book => {
      // Filter by search term (title, author, description)
      if (filter.searchTerm && !filter.searchTerm.trim().split(' ').some(term => {
        const searchText = `${book.title} ${book.author} ${book.description || ''}`.toLowerCase();
        return searchText.includes(term.toLowerCase());
      })) {
        return false;
      }
      
      // Filter by genre
      if (filter.genre && book.genre !== filter.genre) {
        return false;
      }
      
      // Filter by language
      if (filter.language && book.language !== filter.language) {
        return false;
      }
      
      // Filter by privacy
      if (filter.isPublic !== undefined && book.isPublic !== filter.isPublic) {
        return false;
      }
      
      // Filter by tags
      if (filter.tags && filter.tags.length > 0) {
        if (!book.tags || !filter.tags.some(tag => book.tags.includes(tag))) {
          return false;
        }
      }
      
      return true;
    });
  };

  const addBookmark = async (
    bookmarkData: Omit<Bookmark, 'id' | 'userId' | 'createdAt'>
  ): Promise<string> => {
    if (!user) return '';
    
    const newBookmark: Bookmark = {
      ...bookmarkData,
      id: crypto.randomUUID(),
      userId: user.id,
      createdAt: new Date(),
    };

    const allBookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
    allBookmarks.push(newBookmark);
    localStorage.setItem('bookmarks', JSON.stringify(allBookmarks));
    
    setBookmarks(prevBookmarks => [...prevBookmarks, newBookmark]);
    return newBookmark.id;
  };

  const removeBookmark = async (id: string): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const allBookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
      const updatedBookmarks = allBookmarks.filter(
        (bookmark: Bookmark) => !(bookmark.id === id && bookmark.userId === user.id)
      );
      
      localStorage.setItem('bookmarks', JSON.stringify(updatedBookmarks));
      
      setBookmarks(prevBookmarks => 
        prevBookmarks.filter(bookmark => bookmark.id !== id)
      );
      
      return true;
    } catch (error) {
      console.error('Error removing bookmark:', error);
      return false;
    }
  };

  const getBookmarks = (bookId: string): Bookmark[] => {
    return bookmarks.filter(bookmark => bookmark.bookId === bookId);
  };

  const updateReadingSettings = (settings: Partial<ReadingSettings>) => {
    setReadingSettings(prevSettings => ({
      ...prevSettings,
      ...settings,
    }));
  };

  const updateReadingProgress = async (
    bookId: string, 
    page: number
  ): Promise<boolean> => {
    return updateBook(bookId, {
      currentPage: page,
      lastRead: new Date(),
    });
  };

  return (
    <LibraryContext.Provider
      value={{
        books,
        bookmarks,
        readingSettings,
        loading,
        addBook,
        updateBook,
        deleteBook,
        getBook,
        filterBooks,
        addBookmark,
        removeBookmark,
        getBookmarks,
        updateReadingSettings,
        updateReadingProgress,
      }}
    >
      {children}
    </LibraryContext.Provider>
  );
};