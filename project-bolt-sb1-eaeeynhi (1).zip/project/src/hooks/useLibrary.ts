import { useContext } from 'react';
import { LibraryContext } from '../contexts/LibraryContext';

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  
  if (context === undefined) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  
  return context;
};