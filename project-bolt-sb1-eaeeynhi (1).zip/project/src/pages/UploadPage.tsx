import BookUploader from '../components/library/BookUploader';

const UploadPage = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-blue-900">Upload Book</h1>
        <p className="text-gray-600 mt-2">
          Add a new eBook to your personal library
        </p>
      </div>
      
      <BookUploader />
    </div>
  );
};

export default UploadPage;