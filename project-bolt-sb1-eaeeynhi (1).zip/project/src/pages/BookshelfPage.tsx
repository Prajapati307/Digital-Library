import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Search, Filter, X, Book as BookIcon } from 'lucide-react';
import { useLibrary } from '../hooks/useLibrary';
import BookGrid from '../components/library/BookGrid';
import { BookFilter as BookFilterType } from '../types';

const BookshelfPage = () => {
  const location = useLocation();
  const { books, filterBooks } = useLibrary();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [showPrivate, setShowPrivate] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [filteredBooks, setFilteredBooks] = useState(books);
  
  // Extract available genres and languages from books
  const genres = [...new Set(books.map(book => book.genre).filter(Boolean))];
  const languages = [...new Set(books.map(book => book.language).filter(Boolean))];
  
  useEffect(() => {
    // Check for URL params
    const params = new URLSearchParams(location.search);
    const filterParam = params.get('filter');
    
    if (filterParam === 'recent') {
      // Filter by recently read
      const withReadDate = books.filter(book => book.lastRead);
      const sortedByReadDate = [...withReadDate].sort((a, b) => {
        return new Date(b.lastRead!).getTime() - new Date(a.lastRead!).getTime();
      });
      setFilteredBooks(sortedByReadDate);
    } else if (filterParam === 'favorites') {
      // This would be implemented with a favorites system
      setFilteredBooks(books);
    } else {
      applyFilters();
    }
  }, [location.search, books]);
  
  const applyFilters = () => {
    const filter: BookFilterType = {
      searchTerm: searchTerm,
      genre: selectedGenre || undefined,
      language: selectedLanguage || undefined,
    };
    
    // Only apply privacy filter if private books should be excluded
    if (!showPrivate) {
      filter.isPublic = true;
    }
    
    const filtered = filterBooks(filter);
    setFilteredBooks(filtered);
  };
  
  useEffect(() => {
    applyFilters();
  }, [searchTerm, selectedGenre, selectedLanguage, showPrivate]);
  
  const resetFilters = () => {
    setSearchTerm('');
    setSelectedGenre('');
    setSelectedLanguage('');
    setShowPrivate(true);
  };
  
  const hasActiveFilters = searchTerm || selectedGenre || selectedLanguage || !showPrivate;
  
  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex flex-col mb-8">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-blue-900">My Bookshelf</h1>
          
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="btn btn-outline flex items-center"
          >
            <Filter size={16} className="mr-2" />
            Filters
          </button>
        </div>
        
        {/* Search input */}
        <div className="relative mb-4">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search by title, author, or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input pl-10"
          />
        </div>
        
        {/* Filters section */}
        {showFilters && (
          <div className="bg-gray-50 p-4 rounded-md mb-4 border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Filter Books</h3>
              {hasActiveFilters && (
                <button
                  onClick={resetFilters}
                  className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                >
                  <X size={14} className="mr-1" />
                  Reset Filters
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Genre filter */}
              <div>
                <label htmlFor="genre-filter" className="block text-sm font-medium text-gray-700 mb-1">
                  Genre
                </label>
                <select
                  id="genre-filter"
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="input"
                >
                  <option value="">All Genres</option>
                  {genres.map((genre) => (
                    <option key={genre} value={genre}>
                      {genre}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Language filter */}
              <div>
                <label htmlFor="language-filter" className="block text-sm font-medium text-gray-700 mb-1">
                  Language
                </label>
                <select
                  id="language-filter"
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value)}
                  className="input"
                >
                  <option value="">All Languages</option>
                  {languages.map((language) => (
                    <option key={language} value={language}>
                      {language}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Privacy filter */}
              <div className="flex items-center h-full pt-6">
                <input
                  id="privacy-filter"
                  type="checkbox"
                  checked={showPrivate}
                  onChange={(e) => setShowPrivate(e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="privacy-filter" className="ml-2 block text-sm text-gray-700">
                  Show private books
                </label>
              </div>
            </div>
          </div>
        )}
        
        {/* Active filters display */}
        {hasActiveFilters && (
          <div className="flex flex-wrap gap-2 mb-4">
            {searchTerm && (
              <span className="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800">
                Search: {searchTerm}
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="ml-1 inline-flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-blue-600 hover:bg-blue-200 hover:text-blue-900 focus:outline-none"
                >
                  <span className="sr-only">Remove filter</span>
                  <X size={12} />
                </button>
              </span>
            )}
            
            {selectedGenre && (
              <span className="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800">
                Genre: {selectedGenre}
                <button
                  type="button"
                  onClick={() => setSelectedGenre('')}
                  className="ml-1 inline-flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-blue-600 hover:bg-blue-200 hover:text-blue-900 focus:outline-none"
                >
                  <span className="sr-only">Remove filter</span>
                  <X size={12} />
                </button>
              </span>
            )}
            
            {selectedLanguage && (
              <span className="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800">
                Language: {selectedLanguage}
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('')}
                  className="ml-1 inline-flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-blue-600 hover:bg-blue-200 hover:text-blue-900 focus:outline-none"
                >
                  <span className="sr-only">Remove filter</span>
                  <X size={12} />
                </button>
              </span>
            )}
            
            {!showPrivate && (
              <span className="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800">
                Public Only
                <button
                  type="button"
                  onClick={() => setShowPrivate(true)}
                  className="ml-1 inline-flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-blue-600 hover:bg-blue-200 hover:text-blue-900 focus:outline-none"
                >
                  <span className="sr-only">Remove filter</span>
                  <X size={12} />
                </button>
              </span>
            )}
          </div>
        )}
      </div>
      
      {/* Books grid */}
      {filteredBooks.length > 0 ? (
        <BookGrid 
          books={filteredBooks} 
          className="mb-8"
        />
      ) : (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <BookIcon size={48} className="mx-auto text-gray-300 mb-4" />
          <h2 className="text-xl font-bold mb-2">No books found</h2>
          <p className="text-gray-600">
            {books.length === 0
              ? "Your library is empty. Start by uploading your first book."
              : "No books match your current filters. Try adjusting your search criteria."}
          </p>
        </div>
      )}
    </div>
  );
};

export default BookshelfPage;