import React from 'react';
import { Link, Navigate } from 'react-router-dom';
import { BookOpen, Upload, Search, Library, CloudLightning, Lock } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

const Welcome: React.FC = () => {
  const { status } = useAuth();
  
  if (status === 'authenticated') {
    return <Navigate to="/app" replace />;
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <svg width="32" height="32" viewBox="0 0 24 24" className="fill-blue-800 mr-2">
                <path d="M4 19.5C4 20.163 4.224 20.796 4.624 21.268C5.023 21.739 5.571 22.0136 6.16 22.05L6.4 22.06H19.4C19.961 22.0614 20.5003 21.8543 20.9136 21.4799C21.327 21.1055 21.5844 20.5908 21.632 20.032L21.64 19.82V18.75H4V19.5Z" />
                <path d="M21.04 4.78L21.04 18.75H4.00004V4.25C4.00004 3.587 4.22404 2.954 4.62404 2.482C5.02304 2.011 5.57104 1.7364 6.16004 1.7L6.40004 1.69H18.8C19.215 1.68996 19.6214 1.80301 19.9783 2.01682C20.3351 2.23063 20.6296 2.5373 20.8338 2.90491C21.038 3.27252 21.1449 3.68631 21.1436 4.10708C21.1423 4.52784 21.0328 4.94089 20.826 5.307L21.04 4.78Z" />
                <path d="M7.25 7.25L18.25 7.25V8.75L7.25 8.75L7.25 7.25Z" fill="white"/>
                <path d="M7.25 11.25L13.25 11.25V12.75L7.25 12.75V11.25Z" fill="white"/>
              </svg>
              <h1 className="text-xl font-bold text-blue-800">LibraVault</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login" className="btn btn-outline text-sm">
                Sign In
              </Link>
              <Link to="/register" className="btn btn-primary text-sm">
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </header>
      
      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div className="mb-10 lg:mb-0">
              <h1 className="text-4xl font-bold text-blue-900 mb-6 leading-tight md:text-5xl">
                Your personal digital library, anywhere you go
              </h1>
              <p className="text-lg text-slate-600 mb-8">
                Upload, organize, and read your eBooks in one beautiful library. Access your collection anywhere, anytime, on any device.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register" className="btn btn-primary text-center px-8 py-3">
                  Get Started
                </Link>
                <Link to="/login" className="btn btn-outline text-center px-8 py-3">
                  Sign In
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="w-full h-96 lg:h-[500px] relative overflow-hidden rounded-lg shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/590493/pexels-photo-590493.jpeg" 
                  alt="Digital library with books" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/70 to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Your eBooks, Organized</h3>
                  <p>Keep all your reading material in one beautiful library.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-blue-900">Everything you need for your eBook collection</h2>
            <p className="mt-4 text-lg text-slate-600 max-w-3xl mx-auto">
              LibraVault combines powerful organization tools with a beautiful reading experience to create the perfect home for your digital books.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Upload className="w-10 h-10" />}
              title="Easy Uploads"
              description="Upload eBooks in PDF or ePub format directly from your device into your personal library."
            />
            <FeatureCard 
              icon={<BookOpen className="w-10 h-10" />}
              title="Beautiful Reader"
              description="Read your books with a customizable reading experience that adapts to your preferences."
            />
            <FeatureCard 
              icon={<Search className="w-10 h-10" />}
              title="Smart Search"
              description="Find any book in your collection instantly with powerful search and filtering tools."
            />
            <FeatureCard 
              icon={<Library className="w-10 h-10" />}
              title="Organized Bookshelf"
              description="Keep your library organized with custom tags, categories and reading progress tracking."
            />
            <FeatureCard 
              icon={<CloudLightning className="w-10 h-10" />}
              title="Cloud Sync"
              description="Access your library from any device with automatic synchronization of your collection."
            />
            <FeatureCard 
              icon={<Lock className="w-10 h-10" />}
              title="Privacy Controls"
              description="Control which books are private and which ones you want to share with others."
            />
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to start your digital library?</h2>
          <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of readers who have already organized their eBook collections with LibraVault.
          </p>
          <Link to="/register" className="btn bg-white text-blue-800 hover:bg-blue-50 px-8 py-3">
            Create Your Library
          </Link>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <svg width="32" height="32" viewBox="0 0 24 24" className="fill-white mr-2">
                  <path d="M4 19.5C4 20.163 4.224 20.796 4.624 21.268C5.023 21.739 5.571 22.0136 6.16 22.05L6.4 22.06H19.4C19.961 22.0614 20.5003 21.8543 20.9136 21.4799C21.327 21.1055 21.5844 20.5908 21.632 20.032L21.64 19.82V18.75H4V19.5Z" />
                  <path d="M21.04 4.78L21.04 18.75H4.00004V4.25C4.00004 3.587 4.22404 2.954 4.62404 2.482C5.02304 2.011 5.57104 1.7364 6.16004 1.7L6.40004 1.69H18.8C19.215 1.68996 19.6214 1.80301 19.9783 2.01682C20.3351 2.23063 20.6296 2.5373 20.8338 2.90491C21.038 3.27252 21.1449 3.68631 21.1436 4.10708C21.1423 4.52784 21.0328 4.94089 20.826 5.307L21.04 4.78Z" />
                  <path d="M7.25 7.25L18.25 7.25V8.75L7.25 8.75L7.25 7.25Z" fill="white"/>
                  <path d="M7.25 11.25L13.25 11.25V12.75L7.25 12.75V11.25Z" fill="white"/>
                </svg>
                <h3 className="text-xl font-bold">LibraVault</h3>
              </div>
              <p className="text-slate-400 text-sm">
                Your personal digital library platform. Upload, organize, and read your eBooks anywhere.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><a href="#" className="hover:text-white">Features</a></li>
                <li><a href="#" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Resources</h3>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">Guides</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-12 pt-8 text-center text-sm text-slate-500">
            <p>&copy; {new Date().getFullYear()} LibraVault. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-gray-50 p-6 rounded-lg transition-transform duration-300 hover:-translate-y-1 hover:shadow-md">
      <div className="text-blue-800 mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2 text-blue-900">{title}</h3>
      <p className="text-slate-600">{description}</p>
    </div>
  );
};

export default Welcome;