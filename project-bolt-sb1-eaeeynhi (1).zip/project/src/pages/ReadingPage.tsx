import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Bookmark, Share } from 'lucide-react';
import { useLibrary } from '../hooks/useLibrary';
import ReaderControls from '../components/reader/ReaderControls';
import ReaderSettings from '../components/reader/ReaderSettings';

const ReadingPage = () => {
  const { bookId } = useParams<{ bookId: string }>();
  const navigate = useNavigate();
  const { getBook, readingSettings, updateReadingSettings, updateReadingProgress } = useLibrary();
  
  const [book, setBook] = useState(bookId ? getBook(bookId) : undefined);
  const [currentPage, setCurrentPage] = useState(1);
  const [showSettings, setShowSettings] = useState(false);
  
  // Set initial page from book's saved progress
  useEffect(() => {
    if (book && book.currentPage) {
      setCurrentPage(book.currentPage);
    }
  }, [book]);
  
  // Redirect if book not found
  useEffect(() => {
    if (!book && bookId) {
      navigate('/app/bookshelf');
    }
  }, [book, bookId, navigate]);
  
  if (!book) {
    return <div>Loading...</div>;
  }
  
  const handleNextPage = () => {
    if (currentPage < (book.totalPages || 100)) {
      setCurrentPage(prev => prev + 1);
      updateReadingProgress(book.id, currentPage + 1);
    }
  };
  
  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(prev => prev - 1);
      updateReadingProgress(book.id, currentPage - 1);
    }
  };
  
  const addBookmark = () => {
    // Implement bookmark functionality
    alert(`Bookmark added on page ${currentPage}`);
  };
  
  // Set theme class based on reading settings
  let themeClass = '';
  switch (readingSettings.theme) {
    case 'dark':
      themeClass = 'bg-gray-900 text-gray-100';
      break;
    case 'sepia':
      themeClass = 'bg-amber-50 text-amber-900';
      break;
    default:
      themeClass = 'bg-white text-gray-800';
  }
  
  return (
    <div className={`min-h-screen flex flex-col ${themeClass} -mx-4 -my-6 px-4 py-6`}>
      {/* Top bar */}
      <div className="flex items-center justify-between mb-8">
        <Link 
          to="/app/bookshelf"
          className={`p-2 rounded-full hover:bg-opacity-10 hover:bg-gray-500 transition`}
        >
          <ArrowLeft size={24} />
        </Link>
        
        <div className="text-center">
          <h1 className="text-lg font-bold line-clamp-1">{book.title}</h1>
          <p className="text-sm opacity-75">{book.author}</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            className={`p-2 rounded-full hover:bg-opacity-10 hover:bg-gray-500 transition`}
            onClick={addBookmark}
            title="Bookmark this page"
          >
            <Bookmark size={20} />
          </button>
          <button 
            className={`p-2 rounded-full hover:bg-opacity-10 hover:bg-gray-500 transition`}
            title="Share"
          >
            <Share size={20} />
          </button>
        </div>
      </div>
      
      {/* Book content */}
      <div 
        className="reading-content flex-1 mb-16"
        style={{
          fontSize: `${readingSettings.fontSize}px`,
          lineHeight: readingSettings.lineHeight,
          fontFamily: readingSettings.fontFamily
        }}
      >
        {book.fileType === 'pdf' ? (
          <div className="flex items-center justify-center h-full opacity-70">
            <p>PDF preview unavailable. Please use an external PDF viewer.</p>
          </div>
        ) : (
          <div>
            <p className="mb-4">
              <span className="font-bold">Chapter {Math.ceil(currentPage / 5)}</span> - Page {currentPage}
            </p>
            
            <p className="mb-6">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed luctus, nisl eget aliquam tincidunt, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Sed luctus, nisl eget aliquam tincidunt, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl.
            </p>
            
            <p className="mb-6">
              Nullam euismod, nisl eget aliquam tincidunt, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Sed luctus, nisl eget aliquam tincidunt, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl.
            </p>
            
            <p className="mb-6">
              "Fascinating," she said, looking out over the valley. "I never imagined it would be so vast." The mountains in the distance seemed to ripple like waves in the heat of the midday sun.
            </p>
            
            <p className="mb-6">
              He nodded slowly, taking in the breathtaking view. "My grandfather used to tell stories about this place. About how the ancient people believed the valley was a gateway between worlds."
            </p>
            
            <p>
              The wind picked up, carrying with it the scent of wild sage and distant rain. Perhaps there was some truth to those old legends after all.
            </p>
          </div>
        )}
      </div>
      
      {/* Reader controls */}
      <ReaderControls 
        bookId={book.id}
        currentPage={currentPage}
        totalPages={book.totalPages || 100}
        onNextPage={handleNextPage}
        onPrevPage={handlePrevPage}
        onSettingsOpen={() => setShowSettings(true)}
        onAddBookmark={addBookmark}
      />
      
      {/* Settings modal */}
      {showSettings && (
        <ReaderSettings 
          settings={readingSettings}
          onSettingsChange={updateReadingSettings}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
};

export default ReadingPage;