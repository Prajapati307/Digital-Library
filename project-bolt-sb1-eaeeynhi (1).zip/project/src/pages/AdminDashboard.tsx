import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { User, Book, Bookmark } from '../types';
import { useAuth } from '../hooks/useAuth';
import { Users, BookOpen, Bookmark as BookmarkIcon, Search, Trash2, Eye } from 'lucide-react';

const AdminDashboard = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [books, setBooks] = useState<Book[]>([]);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  useEffect(() => {
    // Load all users from localStorage
    const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    setUsers(storedUsers);

    // Load all books
    const storedBooks = JSON.parse(localStorage.getItem('books') || '[]');
    setBooks(storedBooks);

    // Load all bookmarks
    const storedBookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
    setBookmarks(storedBookmarks);
  }, []);

  // Only allow access if user is admin
  if (!user?.isAdmin) {
    return <Navigate to="/app" replace />;
  }

  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getUserBooks = (userId: string) => {
    return books.filter(book => book.userId === userId);
  };

  const getUserBookmarks = (userId: string) => {
    return bookmarks.filter(bookmark => bookmark.userId === userId);
  };

  const deleteUser = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      // Remove user
      const updatedUsers = users.filter(u => u.id !== userId);
      localStorage.setItem('users', JSON.stringify(updatedUsers));
      setUsers(updatedUsers);

      // Remove user's books
      const updatedBooks = books.filter(b => b.userId !== userId);
      localStorage.setItem('books', JSON.stringify(updatedBooks));
      setBooks(updatedBooks);

      // Remove user's bookmarks
      const updatedBookmarks = bookmarks.filter(b => b.userId !== userId);
      localStorage.setItem('bookmarks', JSON.stringify(updatedBookmarks));
      setBookmarks(updatedBookmarks);

      setSelectedUser(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-blue-900">Admin Dashboard</h1>
        <p className="text-gray-600 mt-2">Manage users and view their data</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card p-6 flex items-center">
          <div className="p-3 rounded-lg bg-blue-100 text-blue-800 mr-4">
            <Users size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Users</h3>
            <p className="text-2xl font-bold">{users.length}</p>
          </div>
        </div>

        <div className="card p-6 flex items-center">
          <div className="p-3 rounded-lg bg-amber-100 text-amber-800 mr-4">
            <BookOpen size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Books</h3>
            <p className="text-2xl font-bold">{books.length}</p>
          </div>
        </div>

        <div className="card p-6 flex items-center">
          <div className="p-3 rounded-lg bg-emerald-100 text-emerald-800 mr-4">
            <BookmarkIcon size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Bookmarks</h3>
            <p className="text-2xl font-bold">{bookmarks.length}</p>
          </div>
        </div>
      </div>

      <div className="flex gap-6">
        <div className="w-1/3">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Users</h2>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search users..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 pr-4 py-2 border rounded-md text-sm"
                />
                <Search size={16} className="absolute left-2 top-2.5 text-gray-400" />
              </div>
            </div>

            <div className="space-y-2">
              {filteredUsers.map(u => (
                <div
                  key={u.id}
                  className={`p-3 rounded-md cursor-pointer flex items-center justify-between ${
                    selectedUser?.id === u.id ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedUser(u)}
                >
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                      <span className="text-blue-800 font-medium">
                        {u.username.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">{u.username}</p>
                      <p className="text-sm text-gray-500">{u.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedUser(u);
                      }}
                      className="p-1 text-gray-400 hover:text-blue-600"
                    >
                      <Eye size={16} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteUser(u.id);
                      }}
                      className="p-1 text-gray-400 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="w-2/3">
          {selectedUser ? (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-2">{selectedUser.username}</h2>
                <p className="text-gray-600">{selectedUser.email}</p>
                <p className="text-sm text-gray-500">
                  Member since {new Date(selectedUser.createdAt).toLocaleDateString()}
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="text-sm font-medium text-gray-500">Books</h3>
                  <p className="text-2xl font-bold">{getUserBooks(selectedUser.id).length}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="text-sm font-medium text-gray-500">Bookmarks</h3>
                  <p className="text-2xl font-bold">{getUserBookmarks(selectedUser.id).length}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="text-sm font-medium text-gray-500">Last Active</h3>
                  <p className="text-2xl font-bold">
                    {getUserBooks(selectedUser.id).reduce((latest, book) => {
                      if (!book.lastRead) return latest;
                      return !latest || new Date(book.lastRead) > new Date(latest)
                        ? book.lastRead
                        : latest;
                    }, null) ? new Date(getUserBooks(selectedUser.id).reduce((latest, book) => {
                      if (!book.lastRead) return latest;
                      return !latest || new Date(book.lastRead) > new Date(latest)
                        ? book.lastRead
                        : latest;
                    }, null)!).toLocaleDateString() : 'Never'}
                  </p>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Books</h3>
                  <div className="space-y-2">
                    {getUserBooks(selectedUser.id).map(book => (
                      <div key={book.id} className="p-4 border rounded-md">
                        <div className="flex justify-between">
                          <div>
                            <h4 className="font-medium">{book.title}</h4>
                            <p className="text-sm text-gray-600">{book.author}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-500">
                              Added: {new Date(book.addedAt).toLocaleDateString()}
                            </p>
                            {book.lastRead && (
                              <p className="text-sm text-gray-500">
                                Last read: {new Date(book.lastRead).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        </div>
                        {book.currentPage && book.totalPages && (
                          <div className="mt-2">
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full"
                                style={{
                                  width: `${(book.currentPage / book.totalPages) * 100}%`
                                }}
                              />
                            </div>
                            <p className="text-sm text-gray-500 mt-1">
                              Progress: {book.currentPage} of {book.totalPages} pages
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Bookmarks</h3>
                  <div className="space-y-2">
                    {getUserBookmarks(selectedUser.id).map(bookmark => {
                      const book = books.find(b => b.id === bookmark.bookId);
                      return (
                        <div key={bookmark.id} className="p-4 border rounded-md">
                          <div className="flex justify-between">
                            <div>
                              <h4 className="font-medium">{book?.title}</h4>
                              <p className="text-sm text-gray-600">Page {bookmark.page}</p>
                            </div>
                            <p className="text-sm text-gray-500">
                              {new Date(bookmark.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          {bookmark.note && (
                            <p className="mt-2 text-sm text-gray-600">{bookmark.note}</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Users size={48} className="mx-auto text-gray-300 mb-4" />
              <h2 className="text-xl font-bold mb-2">Select a User</h2>
              <p className="text-gray-600">
                Choose a user from the list to view their details
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;