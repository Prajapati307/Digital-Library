import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { User as UserIcon, Mail, Key, LogOut, Settings, Camera } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useLibrary } from '../hooks/useLibrary';

const ProfilePage = () => {
  const location = useLocation();
  const { user, updateProfile, logout } = useAuth();
  const { books, bookmarks } = useLibrary();
  
  const [activeTab, setActiveTab] = useState<'profile' | 'settings'>('profile');
  const [editing, setEditing] = useState(false);
  const [userData, setUserData] = useState({
    username: user?.username || '',
    email: user?.email || '',
    profilePicture: user?.profilePicture || '',
  });
  const [password, setPassword] = useState({
    current: '',
    new: '',
    confirm: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  useEffect(() => {
    // Check URL params for active tab
    const params = new URLSearchParams(location.search);
    const tab = params.get('tab');
    if (tab === 'settings') {
      setActiveTab('settings');
    } else {
      setActiveTab('profile');
    }
  }, [location]);
  
  useEffect(() => {
    if (user) {
      setUserData({
        username: user.username,
        email: user.email,
        profilePicture: user.profilePicture || '',
      });
    }
  }, [user]);
  
  const handleProfilePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUserData({
            ...userData,
            profilePicture: event.target.result as string,
          });
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserData({
      ...userData,
      [name]: value,
    });
  };
  
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPassword({
      ...password,
      [name]: value,
    });
  };
  
  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    try {
      // Validate inputs
      if (!userData.username.trim()) {
        setError('Username is required');
        return;
      }
      
      if (!userData.email.trim() || !/\S+@\S+\.\S+/.test(userData.email)) {
        setError('Valid email is required');
        return;
      }
      
      const success = await updateProfile({
        username: userData.username,
        email: userData.email,
        profilePicture: userData.profilePicture,
      });
      
      if (success) {
        setSuccess('Profile updated successfully');
        setEditing(false);
      } else {
        setError('Failed to update profile');
      }
    } catch (err) {
      setError('An error occurred while updating profile');
      console.error('Profile update error:', err);
    }
  };
  
  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    // Validate password
    if (!password.current) {
      setError('Current password is required');
      return;
    }
    
    if (password.new.length < 6) {
      setError('New password must be at least 6 characters');
      return;
    }
    
    if (password.new !== password.confirm) {
      setError('New passwords do not match');
      return;
    }
    
    // In a real app, we would verify the current password and update
    // For this demo, just show success
    setSuccess('Password updated successfully');
    setPassword({
      current: '',
      new: '',
      confirm: '',
    });
  };
  
  if (!user) {
    return <div>Loading...</div>;
  }
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-blue-900">My Profile</h1>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex -mb-px">
          <button
            className={`py-4 px-6 font-medium text-sm border-b-2 ${
              activeTab === 'profile'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('profile')}
          >
            Profile
          </button>
          <button
            className={`py-4 px-6 font-medium text-sm border-b-2 ${
              activeTab === 'settings'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('settings')}
          >
            Settings
          </button>
        </div>
      </div>
      
      {/* Profile tab */}
      {activeTab === 'profile' && (
        <div className="mt-6">
          <div className="bg-white shadow rounded-lg overflow-hidden">
            {/* Profile header */}
            <div className="p-6 sm:p-8 bg-blue-50 border-b">
              <div className="flex flex-col sm:flex-row items-center">
                <div className="relative mb-4 sm:mb-0 sm:mr-6">
                  <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-200 flex items-center justify-center">
                    {userData.profilePicture ? (
                      <img
                        src={userData.profilePicture}
                        alt={userData.username}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <UserIcon size={40} className="text-gray-400" />
                    )}
                  </div>
                  
                  {editing && (
                    <div className="absolute bottom-0 right-0">
                      <label
                        htmlFor="profile-picture"
                        className="p-2 bg-blue-600 text-white rounded-full cursor-pointer hover:bg-blue-700"
                      >
                        <Camera size={16} />
                      </label>
                      <input
                        type="file"
                        id="profile-picture"
                        accept="image/*"
                        className="hidden"
                        onChange={handleProfilePictureChange}
                      />
                    </div>
                  )}
                </div>
                
                <div className="text-center sm:text-left">
                  <h2 className="text-2xl font-bold">{user.username}</h2>
                  <p className="text-sm text-gray-600">Member since {new Date(user.createdAt).toLocaleDateString()}</p>
                  <p className="mt-2 text-sm text-gray-600">{user.email}</p>
                  
                  {!editing && (
                    <button
                      onClick={() => setEditing(true)}
                      className="mt-4 btn btn-outline text-sm px-4"
                    >
                      Edit Profile
                    </button>
                  )}
                </div>
              </div>
            </div>
            
            {/* Profile form */}
            {editing ? (
              <form onSubmit={handleProfileUpdate} className="p-6">
                {error && (
                  <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
                    {error}
                  </div>
                )}
                
                {success && (
                  <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md text-sm">
                    {success}
                  </div>
                )}
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="username" className="label">
                      Username
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <UserIcon size={16} className="text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="username"
                        name="username"
                        value={userData.username}
                        onChange={handleInputChange}
                        className="input pl-10"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="label">
                      Email
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail size={16} className="text-gray-400" />
                      </div>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={userData.email}
                        onChange={handleInputChange}
                        className="input pl-10"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => {
                      setEditing(false);
                      setError('');
                      setSuccess('');
                      setUserData({
                        username: user.username,
                        email: user.email,
                        profilePicture: user.profilePicture || '',
                      });
                    }}
                    className="btn btn-outline"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Changes
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-6">
                {/* Statistics */}
                <h3 className="text-lg font-medium mb-4">Library Statistics</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-md text-center">
                    <p className="text-2xl font-bold text-blue-600">{books.length}</p>
                    <p className="text-sm text-gray-600">Books</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-md text-center">
                    <p className="text-2xl font-bold text-blue-600">
                      {books.filter(book => book.totalPages && book.currentPage === book.totalPages).length}
                    </p>
                    <p className="text-sm text-gray-600">Completed</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-md text-center">
                    <p className="text-2xl font-bold text-blue-600">{bookmarks.length}</p>
                    <p className="text-sm text-gray-600">Bookmarks</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-md text-center">
                    <p className="text-2xl font-bold text-blue-600">
                      {books.filter(book => book.lastRead).length}
                    </p>
                    <p className="text-sm text-gray-600">Recently Read</p>
                  </div>
                </div>
                
                {/* Account actions */}
                <div className="mt-8">
                  <h3 className="text-lg font-medium mb-4">Account Actions</h3>
                  <div className="space-y-3">
                    <button
                      onClick={() => setActiveTab('settings')}
                      className="w-full text-left px-4 py-3 flex items-center rounded-md hover:bg-gray-50"
                    >
                      <Settings size={18} className="text-gray-500 mr-3" />
                      <span>Account Settings</span>
                    </button>
                    <button
                      onClick={logout}
                      className="w-full text-left px-4 py-3 flex items-center rounded-md hover:bg-gray-50 text-red-600"
                    >
                      <LogOut size={18} className="mr-3" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Settings tab */}
      {activeTab === 'settings' && (
        <div className="mt-6">
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-6">Account Settings</h2>
              
              {/* Password change form */}
              <div className="mb-8">
                <h3 className="text-lg font-medium mb-4">Change Password</h3>
                
                {error && (
                  <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
                    {error}
                  </div>
                )}
                
                {success && (
                  <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md text-sm">
                    {success}
                  </div>
                )}
                
                <form onSubmit={handlePasswordUpdate} className="space-y-4">
                  <div>
                    <label htmlFor="current" className="label">
                      Current Password
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Key size={16} className="text-gray-400" />
                      </div>
                      <input
                        type="password"
                        id="current"
                        name="current"
                        value={password.current}
                        onChange={handlePasswordChange}
                        className="input pl-10"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="new" className="label">
                      New Password
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Key size={16} className="text-gray-400" />
                      </div>
                      <input
                        type="password"
                        id="new"
                        name="new"
                        value={password.new}
                        onChange={handlePasswordChange}
                        className="input pl-10"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="confirm" className="label">
                      Confirm New Password
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Key size={16} className="text-gray-400" />
                      </div>
                      <input
                        type="password"
                        id="confirm"
                        name="confirm"
                        value={password.confirm}
                        onChange={handlePasswordChange}
                        className="input pl-10"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                  
                  <div className="pt-2">
                    <button type="submit" className="btn btn-primary">
                      Update Password
                    </button>
                  </div>
                </form>
              </div>
              
              {/* Reading settings */}
              <div>
                <h3 className="text-lg font-medium mb-4">Privacy Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Default Book Privacy</h4>
                      <p className="text-sm text-gray-600">
                        Set the default privacy for newly uploaded books
                      </p>
                    </div>
                    <div className="flex items-center">
                      <label htmlFor="privacy" className="mr-2 text-sm">Private</label>
                      <div className="relative inline-block w-10 mr-2 align-middle select-none">
                        <input
                          type="checkbox"
                          id="privacy"
                          className="sr-only"
                        />
                        <div className="w-10 h-4 bg-gray-300 rounded-full shadow-inner"></div>
                        <div className="absolute w-6 h-6 bg-white rounded-full shadow -left-1 -top-1 transition"></div>
                      </div>
                      <label htmlFor="privacy" className="text-sm">Public</label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Show Reading Activity</h4>
                      <p className="text-sm text-gray-600">
                        Allow others to see your reading activity
                      </p>
                    </div>
                    <div className="flex items-center">
                      <label htmlFor="activity" className="mr-2 text-sm">Off</label>
                      <div className="relative inline-block w-10 mr-2 align-middle select-none">
                        <input
                          type="checkbox"
                          id="activity"
                          className="sr-only"
                        />
                        <div className="w-10 h-4 bg-gray-300 rounded-full shadow-inner"></div>
                        <div className="absolute w-6 h-6 bg-white rounded-full shadow -left-1 -top-1 transition"></div>
                      </div>
                      <label htmlFor="activity" className="text-sm">On</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;