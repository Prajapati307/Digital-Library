import { useEffect, useState } from 'react';
import { BookOpen, Clock, Upload, LibraryBig } from 'lucide-react';
import { useLibrary } from '../hooks/useLibrary';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';
import BookGrid from '../components/library/BookGrid';
import { Book } from '../types';

const Dashboard = () => {
  const { user } = useAuth();
  const { books, loading } = useLibrary();
  const [recentlyAdded, setRecentlyAdded] = useState<Book[]>([]);
  const [recentlyRead, setRecentlyRead] = useState<Book[]>([]);
  const [totalBooks, setTotalBooks] = useState(0);

  useEffect(() => {
    if (books.length > 0) {
      // Sort books by added date (descending)
      const sortedByDate = [...books].sort((a, b) => {
        return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
      });
      setRecentlyAdded(sortedByDate.slice(0, 6));

      // Sort books by last read date (descending)
      const withReadDate = books.filter(book => book.lastRead);
      const sortedByReadDate = [...withReadDate].sort((a, b) => {
        return new Date(b.lastRead!).getTime() - new Date(a.lastRead!).getTime();
      });
      setRecentlyRead(sortedByReadDate.slice(0, 6));

      setTotalBooks(books.length);
    }
  }, [books]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-800"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-blue-900">Welcome, {user?.username}!</h1>
        <Link to="/app/upload" className="btn btn-primary flex items-center">
          <Upload size={16} className="mr-2" />
          Upload Book
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card p-6 flex items-center">
          <div className="p-3 rounded-lg bg-blue-100 text-blue-800 mr-4">
            <BookOpen size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Books</h3>
            <p className="text-2xl font-bold">{totalBooks}</p>
          </div>
        </div>
        
        <div className="card p-6 flex items-center">
          <div className="p-3 rounded-lg bg-amber-100 text-amber-800 mr-4">
            <Clock size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Recently Read</h3>
            <p className="text-2xl font-bold">{recentlyRead.length}</p>
          </div>
        </div>
        
        <div className="card p-6 flex items-center">
          <div className="p-3 rounded-lg bg-emerald-100 text-emerald-800 mr-4">
            <LibraryBig size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Completed</h3>
            <p className="text-2xl font-bold">
              {books.filter(book => book.currentPage === book.totalPages).length}
            </p>
          </div>
        </div>
      </div>

      {/* Library sections */}
      <div className="space-y-12">
        {books.length === 0 ? (
          <div className="card p-10 text-center">
            <BookOpen size={48} className="mx-auto text-gray-300 mb-4" />
            <h2 className="text-xl font-bold mb-2">Your library is empty</h2>
            <p className="text-gray-600 mb-6">
              Start by uploading your first eBook to your personal library.
            </p>
            <Link to="/app/upload" className="btn btn-primary inline-flex items-center">
              <Upload size={16} className="mr-2" />
              Upload Your First Book
            </Link>
          </div>
        ) : (
          <>
            {/* Recently Added */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Recently Added</h2>
                <Link to="/app/bookshelf" className="text-blue-600 hover:text-blue-800 text-sm">
                  View All
                </Link>
              </div>
              <BookGrid 
                books={recentlyAdded} 
                emptyMessage="No books added yet"
              />
            </div>

            {/* Recently Read */}
            {recentlyRead.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Continue Reading</h2>
                  <Link to="/app/bookshelf?filter=recent" className="text-blue-600 hover:text-blue-800 text-sm">
                    View All
                  </Link>
                </div>
                <BookGrid 
                  books={recentlyRead} 
                  emptyMessage="No books read yet"
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Dashboard;