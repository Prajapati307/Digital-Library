import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Loading from './components/ui/Loading';
import PrivateRoute from './components/auth/PrivateRoute';
import { useAuth } from './hooks/useAuth';
import Welcome from './pages/Welcome';

// Lazy loaded components
const Login = lazy(() => import('./pages/Login'));
const Register = lazy(() => import('./pages/Register'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const BookshelfPage = lazy(() => import('./pages/BookshelfPage'));
const ReadingPage = lazy(() => import('./pages/ReadingPage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const UploadPage = lazy(() => import('./pages/UploadPage'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));

function App() {
  const { loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/app" element={<Layout />}>
          <Route index element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="bookshelf" element={<PrivateRoute><BookshelfPage /></PrivateRoute>} />
          <Route path="read/:bookId" element={<PrivateRoute><ReadingPage /></PrivateRoute>} />
          <Route path="profile" element={<PrivateRoute><ProfilePage /></PrivateRoute>} />
          <Route path="upload" element={<PrivateRoute><UploadPage /></PrivateRoute>} />
          <Route path="admin" element={<PrivateRoute><AdminDashboard /></PrivateRoute>} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

export default App;