import React from 'react';

const Loading: React.FC = () => {
  return (
    <div className="w-full min-h-screen flex items-center justify-center bg-gray-50">
      <div className="flex flex-col items-center">
        <svg width="60" height="60" viewBox="0 0 24 24" className="fill-blue-800 animate-pulse">
          <path d="M4 19.5C4 20.163 4.224 20.796 4.624 21.268C5.023 21.739 5.571 22.0136 6.16 22.05L6.4 22.06H19.4C19.961 22.0614 20.5003 21.8543 20.9136 21.4799C21.327 21.1055 21.5844 20.5908 21.632 20.032L21.64 19.82V18.75H4V19.5Z" />
          <path d="M21.04 4.78L21.04 18.75H4.00004V4.25C4.00004 3.587 4.22404 2.954 4.62404 2.482C5.02304 2.011 5.57104 1.7364 6.16004 1.7L6.40004 1.69H18.8C19.215 1.68996 19.6214 1.80301 19.9783 2.01682C20.3351 2.23063 20.6296 2.5373 20.8338 2.90491C21.038 3.27252 21.1449 3.68631 21.1436 4.10708C21.1423 4.52784 21.0328 4.94089 20.826 5.307L21.04 4.78Z" />
          <path d="M7.25 7.25L18.25 7.25V8.75L7.25 8.75L7.25 7.25Z" fill="white"/>
          <path d="M7.25 11.25L13.25 11.25V12.75L7.25 12.75V11.25Z" fill="white"/>
        </svg>
        <h2 className="mt-4 text-xl font-semibold text-blue-800">Loading...</h2>
        <p className="mt-2 text-sm text-gray-500">Preparing your library</p>
      </div>
    </div>
  );
};

export default Loading;