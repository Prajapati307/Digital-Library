import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Book, Lock, Unlock, Bookmark, Heart } from 'lucide-react';
import { Book as BookType } from '../../types';

interface BookCardProps {
  book: BookType;
  className?: string;
}

const defaultCover = (title: string, author: string) => {
  // Generate a random color based on the title
  const getColor = () => {
    const colors = [
      'bg-blue-600', 'bg-indigo-600', 'bg-purple-600', 
      'bg-pink-600', 'bg-red-600', 'bg-amber-600',
      'bg-emerald-600', 'bg-teal-600', 'bg-cyan-600'
    ];
    
    // Use a hash function to always get the same color for the same title
    let hash = 0;
    for (let i = 0; i < title.length; i++) {
      hash = title.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div className={`w-full h-full flex items-center justify-center ${getColor()} text-white`}>
      <div className="p-4 text-center">
        <Book size={28} className="mx-auto mb-2" />
        <h3 className="font-bold text-sm line-clamp-2">{title}</h3>
        <p className="text-xs opacity-80 mt-1 line-clamp-1">{author}</p>
      </div>
    </div>
  );
};

const BookCard: React.FC<BookCardProps> = ({ book, className = '' }) => {
  const navigate = useNavigate();
  const { id, title, author, cover, isPublic, currentPage, totalPages } = book;
  
  const readingProgress = totalPages ? Math.round((currentPage || 0) / totalPages * 100) : 0;
  
  const handleClick = () => {
    navigate(`/app/read/${id}`);
  };

  return (
    <div 
      className={`book-appear group transition-all duration-300 ${className}`}
      style={{ animationDelay: `${Math.random() * 0.5}s` }}
    >
      <div className="book-cover relative cursor-pointer group" onClick={handleClick}>
        {cover ? (
          <img
            src={cover}
            alt={`${title} by ${author}`}
            className="w-full h-full object-cover"
          />
        ) : (
          defaultCover(title, author)
        )}
        
        {/* Reading progress */}
        {readingProgress > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200">
            <div 
              className="h-full bg-blue-600"
              style={{ width: `${readingProgress}%` }}
            />
          </div>
        )}
        
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button 
            className="btn btn-primary btn-sm"
            onClick={handleClick}
          >
            Read Now
          </button>
        </div>
        
        {/* Privacy indicator */}
        <div className="absolute top-2 right-2 text-white">
          {isPublic ? (
            <Unlock size={16} className="opacity-70" />
          ) : (
            <Lock size={16} className="opacity-70" />
          )}
        </div>
      </div>
      
      <div className="mt-2">
        <h3 className="font-medium text-sm line-clamp-1" title={title}>{title}</h3>
        <p className="text-xs text-gray-600 line-clamp-1" title={author}>
          {author}
        </p>
        
        {/* Actions */}
        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center gap-1 text-gray-500">
            <Bookmark size={14} className="hover:text-blue-600 cursor-pointer" title="Bookmark" />
            <Heart size={14} className="hover:text-red-500 cursor-pointer" title="Favorite" />
          </div>
          
          {readingProgress > 0 && (
            <span className="text-xs text-gray-500">{readingProgress}%</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookCard;