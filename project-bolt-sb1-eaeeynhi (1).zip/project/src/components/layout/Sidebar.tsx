import { Link, useLocation } from 'react-router-dom';
import { X, Home, BookOpen, Upload, Settings, User, Heart, Clock, Shield } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const location = useLocation();
  const { user } = useAuth();

  const navigation = [
    { name: 'Dashboard', href: '/app', icon: Home },
    { name: 'My Bookshelf', href: '/app/bookshelf', icon: BookOpen },
    { name: 'Upload Book', href: '/app/upload', icon: Upload },
    { name: 'Recently Read', href: '/app/bookshelf?filter=recent', icon: Clock },
    { name: 'Favorites', href: '/app/bookshelf?filter=favorites', icon: Heart },
    { name: 'Profile', href: '/app/profile', icon: User },
    { name: 'Settings', href: '/app/profile?tab=settings', icon: Settings },
    ...(user?.isAdmin ? [{ name: 'Admin', href: '/app/admin', icon: Shield }] : []),
  ];

  return (
    <div 
      className={`fixed inset-0 md:relative md:inset-auto z-20 transform transition-transform duration-300 ease-in-out md:translate-x-0 ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      <div className="flex flex-col w-64 min-h-screen bg-white border-r border-gray-200">
        <div className="flex items-center justify-between h-16 px-4 border-b">
          <div className="flex items-center">
            <svg width="32" height="32" viewBox="0 0 24 24" className="fill-blue-800 mr-2">
              <path d="M4 19.5C4 20.163 4.224 20.796 4.624 21.268C5.023 21.739 5.571 22.0136 6.16 22.05L6.4 22.06H19.4C19.961 22.0614 20.5003 21.8543 20.9136 21.4799C21.327 21.1055 21.5844 20.5908 21.632 20.032L21.64 19.82V18.75H4V19.5Z" />
              <path d="M21.04 4.78L21.04 18.75H4.00004V4.25C4.00004 3.587 4.22404 2.954 4.62404 2.482C5.02304 2.011 5.57104 1.7364 6.16004 1.7L6.40004 1.69H18.8C19.215 1.68996 19.6214 1.80301 19.9783 2.01682C20.3351 2.23063 20.6296 2.5373 20.8338 2.90491C21.038 3.27252 21.1449 3.68631 21.1436 4.10708C21.1423 4.52784 21.0328 4.94089 20.826 5.307L21.04 4.78Z" />
              <path d="M7.25 7.25L18.25 7.25V8.75L7.25 8.75L7.25 7.25Z" fill="white"/>
              <path d="M7.25 11.25L13.25 11.25V12.75L7.25 12.75V11.25Z" fill="white"/>
            </svg>
            <h2 className="text-lg font-bold text-blue-800">LibraVault</h2>
          </div>
          <button
            className="p-2 rounded-md text-gray-500 hover:text-gray-900 focus:outline-none md:hidden"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>
        <div className="flex flex-col flex-1 overflow-y-auto">
          <div className="px-4 py-6">
            <div className="flex items-center mb-6">
              <div className="flex-shrink-0">
                {user?.profilePicture ? (
                  <img
                    className="h-10 w-10 rounded-full object-cover"
                    src={user.profilePicture}
                    alt={user.username}
                  />
                ) : (
                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-blue-800 font-medium">
                      {user?.username?.charAt(0).toUpperCase() || 'U'}
                    </span>
                  </div>
                )}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700">{user?.username}</p>
                <p className="text-xs text-gray-500">@{user?.username?.toLowerCase()}</p>
              </div>
            </div>
            <nav className="space-y-1">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href || 
                  (item.href.includes('?') && 
                   location.pathname === item.href.split('?')[0] && 
                   location.search === item.href.split('?')[1]);
                
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center px-2 py-3 text-sm font-medium rounded-md transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-blue-800'
                        : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                    onClick={onClose}
                  >
                    <Icon
                      size={18}
                      className={`mr-3 flex-shrink-0 ${
                        isActive ? 'text-blue-700' : 'text-gray-500'
                      }`}
                    />
                    {item.name}
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
        <div className="p-4 border-t border-gray-200">
          <p className="text-xs text-gray-500 text-center">
            LibraVault &copy; {new Date().getFullYear()}
          </p>
        </div>
      </div>
      
      {/* Dark overlay for mobile */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 md:hidden ${isOpen ? 'block' : 'hidden'}`}
        onClick={onClose}
      />
    </div>
  );
};

export default Sidebar;