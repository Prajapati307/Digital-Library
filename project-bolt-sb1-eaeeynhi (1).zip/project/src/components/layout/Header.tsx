import { useNavigate } from 'react-router-dom';
import { Menu, Search, User, LogOut, Upload } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useState } from 'react';

interface HeaderProps {
  onMenuClick: () => void;
}

const Header = ({ onMenuClick }: HeaderProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <button 
              onClick={onMenuClick}
              className="p-2 rounded-md text-gray-500 hover:text-gray-900 focus:outline-none md:hidden"
            >
              <Menu size={24} />
            </button>
            <div 
              className="flex items-center cursor-pointer" 
              onClick={() => navigate('/app')}
            >
              <svg width="32" height="32" viewBox="0 0 24 24" className="fill-blue-800 mr-2">
                <path d="M4 19.5C4 20.163 4.224 20.796 4.624 21.268C5.023 21.739 5.571 22.0136 6.16 22.05L6.4 22.06H19.4C19.961 22.0614 20.5003 21.8543 20.9136 21.4799C21.327 21.1055 21.5844 20.5908 21.632 20.032L21.64 19.82V18.75H4V19.5Z" />
                <path d="M21.04 4.78L21.04 18.75H4.00004V4.25C4.00004 3.587 4.22404 2.954 4.62404 2.482C5.02304 2.011 5.57104 1.7364 6.16004 1.7L6.40004 1.69H18.8C19.215 1.68996 19.6214 1.80301 19.9783 2.01682C20.3351 2.23063 20.6296 2.5373 20.8338 2.90491C21.038 3.27252 21.1449 3.68631 21.1436 4.10708C21.1423 4.52784 21.0328 4.94089 20.826 5.307L21.04 4.78Z" />
                <path d="M7.25 7.25L18.25 7.25V8.75L7.25 8.75L7.25 7.25Z" fill="white"/>
                <path d="M7.25 11.25L13.25 11.25V12.75L7.25 12.75V11.25Z" fill="white"/>
              </svg>
              <h1 className="text-xl font-bold text-blue-800">LibraVault</h1>
            </div>
          </div>

          <div className={`flex-1 flex items-center justify-center px-2 ${searchOpen ? 'block' : 'hidden md:flex'}`}>
            <div className="max-w-lg w-full relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search books, authors..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button 
              className="p-2 rounded-md text-gray-500 hover:text-gray-900 focus:outline-none md:hidden"
              onClick={() => setSearchOpen(!searchOpen)}
            >
              <Search size={20} />
            </button>
            
            <button 
              className="p-2 rounded-md text-blue-800 hover:text-blue-900 hover:bg-blue-50 focus:outline-none"
              onClick={() => navigate('/app/upload')}
              title="Upload Book"
            >
              <Upload size={20} />
            </button>
            
            <div className="relative">
              <button 
                className="p-2 rounded-md text-blue-800 hover:text-blue-900 hover:bg-blue-50 focus:outline-none"
                onClick={() => navigate('/app/profile')}
              >
                {user?.profilePicture ? (
                  <img 
                    src={user.profilePicture} 
                    alt={user.username} 
                    className="h-8 w-8 rounded-full"
                  />
                ) : (
                  <User size={20} />
                )}
              </button>
            </div>
            
            <button 
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none"
              onClick={() => logout()}
              title="Logout"
            >
              <LogOut size={20} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;