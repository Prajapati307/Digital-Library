import React from 'react';
import { X, Sun, Moon, SunMoon } from 'lucide-react';
import { ReadingSettings } from '../../types';

interface ReaderSettingsProps {
  settings: ReadingSettings;
  onSettingsChange: (settings: Partial<ReadingSettings>) => void;
  onClose: () => void;
}

const ReaderSettings: React.FC<ReaderSettingsProps> = ({
  settings,
  onSettingsChange,
  onClose,
}) => {
  const themes = [
    { id: 'light', name: 'Light', icon: Sun },
    { id: 'sepia', name: 'Sepia', icon: SunMoon },
    { id: 'dark', name: 'Dark', icon: Moon },
  ];

  const fontFamilies = [
    { id: 'Literata', name: 'Literata (Serif)' },
    { id: 'Inter', name: 'Inter (Sans)' },
    { id: 'monospace', name: 'Monospace' },
  ];

  const fontSizes = [
    { value: 14, name: 'Small' },
    { value: 16, name: 'Medium' },
    { value: 18, name: 'Large' },
    { value: 20, name: 'X-Large' },
    { value: 24, name: 'XX-Large' },
  ];

  const lineHeights = [
    { value: 1.3, name: 'Tight' },
    { value: 1.5, name: 'Normal' },
    { value: 1.8, name: 'Relaxed' },
    { value: 2, name: 'Loose' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b p-4">
          <h2 className="text-lg font-semibold">Reader Settings</h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100"
            aria-label="Close settings"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Theme selector */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Theme</h3>
            <div className="flex gap-3">
              {themes.map(({ id, name, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => onSettingsChange({ theme: id as any })}
                  className={`flex flex-col items-center justify-center p-3 border rounded-lg transition-colors ${
                    settings.theme === id
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  <Icon size={24} className="mb-1" />
                  <span className="text-xs">{name}</span>
                </button>
              ))}
            </div>
          </div>
          
          {/* Font family selector */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Font Family</h3>
            <div className="grid grid-cols-1 gap-2">
              {fontFamilies.map(({ id, name }) => (
                <button
                  key={id}
                  onClick={() => onSettingsChange({ fontFamily: id })}
                  className={`text-left p-3 border rounded transition-colors ${
                    settings.fontFamily === id
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                  style={{ fontFamily: id }}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>
          
          {/* Font size slider */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-700">Font Size</h3>
              <span className="text-sm text-gray-500">{settings.fontSize}px</span>
            </div>
            <input
              type="range"
              min="14"
              max="24"
              step="2"
              value={settings.fontSize}
              onChange={(e) => onSettingsChange({ fontSize: parseInt(e.target.value) })}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>A</span>
              <span style={{ fontSize: '1.2em' }}>A</span>
              <span style={{ fontSize: '1.4em' }}>A</span>
            </div>
          </div>
          
          {/* Line height selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-700">Line Spacing</h3>
              <span className="text-sm text-gray-500">{settings.lineHeight}x</span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {lineHeights.map(({ value, name }) => (
                <button
                  key={value}
                  onClick={() => onSettingsChange({ lineHeight: value })}
                  className={`text-center p-2 border rounded text-sm transition-colors ${
                    settings.lineHeight === value
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="border-t p-4 flex justify-end">
          <button
            onClick={onClose}
            className="btn btn-primary"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReaderSettings;