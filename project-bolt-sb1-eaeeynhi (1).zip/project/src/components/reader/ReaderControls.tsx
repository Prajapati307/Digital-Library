import React from 'react';
import { useLibrary } from '../../hooks/useLibrary';
import { 
  ChevronLeft, 
  ChevronRight, 
  Settings, 
  Bookmark, 
  Sun, 
  Moon,
  SunMoon,
  BookOpen
} from 'lucide-react';

interface ReaderControlsProps {
  bookId: string;
  currentPage: number;
  totalPages: number;
  onNextPage: () => void;
  onPrevPage: () => void;
  onSettingsOpen: () => void;
  onAddBookmark: () => void;
}

const ReaderControls: React.FC<ReaderControlsProps> = ({
  bookId,
  currentPage,
  totalPages,
  onNextPage,
  onPrevPage,
  onSettingsOpen,
  onAddBookmark,
}) => {
  const { readingSettings, updateReadingProgress } = useLibrary();

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      if (newPage > currentPage) {
        onNextPage();
      } else {
        onPrevPage();
      }
      updateReadingProgress(bookId, newPage);
    }
  };

  const getThemeIcon = () => {
    switch (readingSettings.theme) {
      case 'light':
        return <Sun size={18} />;
      case 'dark':
        return <Moon size={18} />;
      case 'sepia':
        return <SunMoon size={18} />;
      default:
        return <Sun size={18} />;
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-md px-4 py-2 z-10 transition-transform">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage <= 1}
            className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Previous page"
          >
            <ChevronLeft size={20} />
          </button>
          
          <div className="flex items-center">
            <input
              type="number"
              value={currentPage}
              min={1}
              max={totalPages}
              onChange={(e) => handlePageChange(parseInt(e.target.value) || 1)}
              className="w-16 border border-gray-300 rounded py-1 px-2 text-center"
              aria-label="Current page"
            />
            <span className="mx-2 text-sm text-gray-500">of {totalPages}</span>
          </div>
          
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage >= totalPages}
            className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Next page"
          >
            <ChevronRight size={20} />
          </button>
        </div>
        
        <div className="flex items-center gap-3">
          <button
            onClick={onAddBookmark}
            className="p-2 rounded-full hover:bg-gray-100"
            aria-label="Add bookmark"
          >
            <Bookmark size={18} />
          </button>
          
          <button
            onClick={onSettingsOpen}
            className="p-2 rounded-full hover:bg-gray-100"
            aria-label="Reader settings"
          >
            <Settings size={18} />
          </button>
          
          <button
            className="p-2 rounded-full hover:bg-gray-100"
            aria-label="Current theme"
          >
            {getThemeIcon()}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReaderControls;