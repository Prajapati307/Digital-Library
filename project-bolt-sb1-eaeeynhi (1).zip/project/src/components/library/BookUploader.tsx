import React, { useState, useRef } from 'react';
import { Upload, FileText, X, BookOpen } from 'lucide-react';
import { useLibrary } from '../../hooks/useLibrary';
import { Book } from '../../types';

const BookUploader: React.FC = () => {
  const { addBook } = useLibrary();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    genre: '',
    language: '',
    description: '',
    isPublic: false,
    tags: '',
    cover: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      
      // Check file type
      const fileType = selectedFile.type;
      const validTypes = ['application/pdf', 'application/epub+zip'];
      
      if (!validTypes.includes(fileType)) {
        setErrors({
          ...errors,
          file: 'Please upload a PDF or ePub file',
        });
        return;
      }
      
      // File is valid, process it
      setFile(selectedFile);
      setErrors({});
      
      // For PDF, create preview
      if (fileType === 'application/pdf') {
        // In a real app, we would use a PDF.js to generate a preview
        // For this demo, we'll just show a generic PDF icon
        setFilePreview(null);
      }
    }
  };

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFormData({
            ...formData,
            cover: event.target.result as string,
          });
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!formData.author.trim()) {
      newErrors.author = 'Author is required';
    }
    
    if (!file) {
      newErrors.file = 'Please upload a book file';
    }
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    // Form is valid, process upload
    setLoading(true);
    
    try {
      // Read file as base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const fileData = event.target.result as string;
          
          // Prepare book data
          const newBook: Omit<Book, 'id' | 'userId' | 'addedAt'> = {
            title: formData.title,
            author: formData.author,
            cover: formData.cover || undefined,
            file: fileData,
            fileType: file.type === 'application/pdf' ? 'pdf' : 'epub',
            genre: formData.genre || undefined,
            language: formData.language || undefined,
            description: formData.description || undefined,
            isPublic: formData.isPublic,
            tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()) : [],
          };
          
          // Add book to library
          const bookId = await addBook(newBook);
          
          if (bookId) {
            // Reset form
            setFile(null);
            setFilePreview(null);
            setFormData({
              title: '',
              author: '',
              genre: '',
              language: '',
              description: '',
              isPublic: false,
              tags: '',
              cover: '',
            });
            setErrors({});
            
            // Show success message
            alert('Book uploaded successfully!');
          }
        }
      };
      
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading book:', error);
      setErrors({
        ...errors,
        general: 'Failed to upload book. Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* File upload area */}
        <div 
          className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
            file ? 'border-green-300 bg-green-50' : 'border-gray-300 hover:border-blue-400'
          }`}
          onClick={() => fileInputRef.current?.click()}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,.epub"
            className="hidden"
          />
          
          {file ? (
            <div className="flex items-center justify-center gap-4">
              <div className="flex items-center">
                <FileText size={24} className="text-green-600 mr-2" />
                <span className="font-medium text-green-600">{file.name}</span>
              </div>
              <button
                type="button"
                className="text-gray-500 hover:text-red-500"
                onClick={(e) => {
                  e.stopPropagation();
                  setFile(null);
                  setFilePreview(null);
                }}
              >
                <X size={20} />
              </button>
            </div>
          ) : (
            <div>
              <Upload size={32} className="mx-auto text-gray-400 mb-2" />
              <p className="text-sm text-gray-600 mb-1">
                Click to upload or drag and drop
              </p>
              <p className="text-xs text-gray-500">PDF or ePub (max 100MB)</p>
            </div>
          )}
          
          {errors.file && (
            <p className="text-sm text-red-500 mt-2">{errors.file}</p>
          )}
        </div>
        
        {/* Book details */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="title" className="label">Title</label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                className="input"
                placeholder="Book title"
              />
              {errors.title && (
                <p className="text-sm text-red-500 mt-1">{errors.title}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="author" className="label">Author</label>
              <input
                type="text"
                id="author"
                name="author"
                value={formData.author}
                onChange={handleInputChange}
                className="input"
                placeholder="Book author"
              />
              {errors.author && (
                <p className="text-sm text-red-500 mt-1">{errors.author}</p>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="genre" className="label">Genre</label>
              <select
                id="genre"
                name="genre"
                value={formData.genre}
                onChange={handleInputChange}
                className="input"
              >
                <option value="">Select a genre</option>
                <option value="fiction">Fiction</option>
                <option value="non-fiction">Non-Fiction</option>
                <option value="mystery">Mystery</option>
                <option value="science-fiction">Science Fiction</option>
                <option value="fantasy">Fantasy</option>
                <option value="romance">Romance</option>
                <option value="thriller">Thriller</option>
                <option value="horror">Horror</option>
                <option value="biography">Biography</option>
                <option value="history">History</option>
                <option value="self-help">Self-Help</option>
                <option value="business">Business</option>
                <option value="other">Other</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="language" className="label">Language</label>
              <select
                id="language"
                name="language"
                value={formData.language}
                onChange={handleInputChange}
                className="input"
              >
                <option value="">Select a language</option>
                <option value="english">English</option>
                <option value="spanish">Spanish</option>
                <option value="french">French</option>
                <option value="german">German</option>
                <option value="italian">Italian</option>
                <option value="portuguese">Portuguese</option>
                <option value="russian">Russian</option>
                <option value="japanese">Japanese</option>
                <option value="chinese">Chinese</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
          
          <div>
            <label htmlFor="description" className="label">Description</label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              className="input min-h-[100px]"
              placeholder="Brief description of the book"
            />
          </div>
          
          <div>
            <label htmlFor="tags" className="label">Tags</label>
            <input
              type="text"
              id="tags"
              name="tags"
              value={formData.tags}
              onChange={handleInputChange}
              className="input"
              placeholder="Enter tags separated by commas"
            />
            <p className="text-xs text-gray-500 mt-1">
              Example: fantasy, adventure, young adult
            </p>
          </div>
          
          <div>
            <label htmlFor="cover" className="label">
              Book Cover (optional)
            </label>
            <div className="flex items-center gap-4">
              <input
                type="file"
                id="cover"
                accept="image/*"
                className="hidden"
                onChange={handleCoverChange}
              />
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => document.getElementById('cover')?.click()}
              >
                Choose Image
              </button>
              
              {formData.cover && (
                <div className="relative w-16 h-24">
                  <img
                    src={formData.cover}
                    alt="Book cover preview"
                    className="w-full h-full object-cover rounded"
                  />
                  <button
                    type="button"
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                    onClick={() => setFormData({ ...formData, cover: '' })}
                  >
                    <X size={14} />
                  </button>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center">
            <input
              type="checkbox"
              id="isPublic"
              name="isPublic"
              checked={formData.isPublic}
              onChange={handleCheckboxChange}
              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <label htmlFor="isPublic" className="ml-2 text-sm text-gray-700">
              Make this book public (visible to other users)
            </label>
          </div>
        </div>
        
        {errors.general && (
          <p className="text-sm text-red-500">{errors.general}</p>
        )}
        
        <div className="flex justify-end">
          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Uploading...' : 'Upload Book'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BookUploader;