import React from 'react';
import { Book } from '../../types';
import BookCard from '../ui/BookCard';
import { BookOpen } from 'lucide-react';

interface BookGridProps {
  books: Book[];
  title?: string;
  emptyMessage?: string;
  className?: string;
}

const BookGrid: React.FC<BookGridProps> = ({ 
  books, 
  title, 
  emptyMessage = "No books found",
  className = "" 
}) => {
  if (books.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-gray-500">
        <BookOpen size={48} className="mb-4 opacity-30" />
        <p>{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className={className}>
      {title && <h2 className="text-xl font-bold mb-4">{title}</h2>}
      <div className="grid grid-cols-auto-fill-xs sm:grid-cols-auto-fill-sm md:grid-cols-auto-fill-md gap-6">
        {books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  );
};

export default BookGrid;